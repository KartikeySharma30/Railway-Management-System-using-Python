/*
-- Query: SELECT * FROM projectrailway.reservation
LIMIT 0, 1000

-- Date: 2021-01-16 23:54
*/
INSERT INTO `` (`Name_Of_Traveller`,`user_Name`,`Age_Of_Traveller`,`Gender_of_Traveller`,`Food_on_rail`,`Date_of_travel`,`TrainName`,`PNR_No`) VALUES ('Kartikey','k@k',17,'Male','Yes','2020-10-16','MUMBAI CENTRAL - AHMEDABAD AC DURONTO EXP',6545664);
INSERT INTO `` (`Name_Of_Traveller`,`user_Name`,`Age_Of_Traveller`,`Gender_of_Traveller`,`Food_on_rail`,`Date_of_travel`,`TrainName`,`PNR_No`) VALUES ('Kartikey','k@k',17,'Male','Yes','2020-10-23','AHMEDABAD - MUMBAI CENT AC DURONTO EXP',36334331);
INSERT INTO `` (`Name_Of_Traveller`,`user_Name`,`Age_Of_Traveller`,`Gender_of_Traveller`,`Food_on_rail`,`Date_of_travel`,`TrainName`,`PNR_No`) VALUES ('Akshat Mishra','Ak@123',17,'Male','N/A','2020-10-16','NEW DELHI - DIBRUGARH TOWN RAJDHANI EXPRESS',81415847);
INSERT INTO `` (`Name_Of_Traveller`,`user_Name`,`Age_Of_Traveller`,`Gender_of_Traveller`,`Food_on_rail`,`Date_of_travel`,`TrainName`,`PNR_No`) VALUES ('Abhishek sharma','k@k',21,'Male','Yes','2020-11-30','MUMBAI CENTRAL - AHMEDABAD AC DURONTO EXP',89496506);
INSERT INTO `` (`Name_Of_Traveller`,`user_Name`,`Age_Of_Traveller`,`Gender_of_Traveller`,`Food_on_rail`,`Date_of_travel`,`TrainName`,`PNR_No`) VALUES ('Akshat Mi','Ak@123',17,'Male','N/A','2020-10-16','AHMEDABAD - MUMBAI CENT AC DURONTO EXP',91474165);
