/*
-- Query: SELECT * FROM projectrailway.coustomer_data
LIMIT 0, 1000

-- Date: 2021-01-16 23:52
*/
INSERT INTO `` (`user_Name`,`password`,`First_Name`,`Last_Name`,`Age`,`Email`,`Aadhar_No`,`Ph_No`,`City`,`PinCode`) VALUES ('Ak@123','AK','Akshat','Mishra',17,'AK@gmail.com','123261454',951147535,'Subroto park,Delhi','110010');
INSERT INTO `` (`user_Name`,`password`,`First_Name`,`Last_Name`,`Age`,`Email`,`Aadhar_No`,`Ph_No`,`City`,`PinCode`) VALUES ('Aryan@20','Aryan','Aryan','Yogi',17,'aryanyogi20@gmail.com','283747261',483829829,'Delhi','110023');
INSERT INTO `` (`user_Name`,`password`,`First_Name`,`Last_Name`,`Age`,`Email`,`Aadhar_No`,`Ph_No`,`City`,`PinCode`) VALUES ('k@k','kk','Kartikey ','Sharma',17,'kartika@gmail.com','123456789',999999999,'Delhi','110010');
INSERT INTO `` (`user_Name`,`password`,`First_Name`,`Last_Name`,`Age`,`Email`,`Aadhar_No`,`Ph_No`,`City`,`PinCode`) VALUES ('Veenu@21','VKS','Vin','Sham',25,'Vin@gmail.com','382384576',819283212,'Dubai','211212');
